package bamfTasker;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.plaf.metal.MetalTreeUI;
import javax.swing.tree.DefaultMutableTreeNode;
import java.awt.Color;

/**
 * This portion of the Tasker App will allow implementation
 * of tasks and task lists. The user will be able to create, modify,
 * and delete tasks and tasks lists.
 * 
 * @author Justin Conner, Group 2-2
 * @version v1.0, November 11, 2013
 */

public class TaskerDashboard extends JFrame {
	
	private static int X_SIZE = 400;
	private static int Y_SIZE = 500;
	private static String actName;
	
	/**
	 * Constructor
	 * @param accountName is fileData.get(0) from TaskerApp
	 */
	public TaskerDashboard(final String accountName)
	{
		this.actName = accountName;
		this.setBounds(0, 0, X_SIZE, Y_SIZE);
		this.setResizable(false);
		getContentPane().setLayout(null);
		
		//Add DynamicTreePanel
		DynamicTreePanel newContentPane = new DynamicTreePanel();
        newContentPane.setOpaque(true); 
        setContentPane(newContentPane);   
        
        //Create menu bar
        JMenuBar menuBar = new JMenuBar(); 
        
        //Set file button on menu bar
        JMenu file = new JMenu("File");
        JMenuItem logoff = new JMenuItem("Log Off");
        file.add(logoff);
        logoff.addActionListener(new ActionListener(){
        	public void actionPerformed(ActionEvent e)
        	{
        		System.exit(0);
        	}
        });
        menuBar.add(file);
        
        //Set account management button on menu bar
        JMenu account = new JMenu("Account Management");
        JMenuItem changeUP = new JMenuItem("Change Username/Password");
        account.add(changeUP);
        changeUP.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				JFrame frame;
				frame = new JFrame("Account Management");
				AccountManagementApp manageApp;
				manageApp = new AccountManagementApp(accountName);
				frame.getContentPane().add(manageApp);
				frame.setBounds(0, 0, 575, 200);
				frame.setVisible(true);
			}
        });
        menuBar.add(account);
        
        
        this.setJMenuBar(menuBar);     
		this.setVisible(true);
	}
	public static void main(String[] args)
	{
		new TaskerDashboard(actName);
	}
}