package bamfTasker;

import io.*;

import java.awt.*;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.*;
import java.util.ArrayList;

import javax.lang.model.element.Element;
import javax.swing.*;
import javax.swing.text.Document;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.XMLReader;

import app.AbstractMultimediaApp;
import app.ResourceFinder;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 * A MultimediaApp that will be used to login a user.
 * 
 * @author Group 2-2, James Madison University
 * @version 1.0 , October 20, 2013
 */
public class TaskerApp extends AbstractMultimediaApp{

	private JLabel username = new JLabel("Username: ");
	private JLabel password = new JLabel("Password: ");
	private JTextField passField = new JTextField(15);
	private JTextField userField = new JTextField(15);
	private JLabel title = new JLabel("BAMFTasker");
	private JButton loginB = new JButton("Login");
	private JButton createB = new JButton("Create User");
	private JButton deleteB = new JButton("Delete User");
	private JButton companyB = new JButton("Company Site");
	private Reader reader = new Reader();
    private Writer writer = new Writer();
    private ArrayList<String> fileData = new ArrayList<String>(1);
	private JPanel contentPane;
    
    /**
     * Shows a dialog in a dialog box
     * @param string what is said in the box
     */
    public void showDialog(String string)
    {
    	JFrame frame = new JFrame();
    	frame.setBounds(500, 500, 150, 50);
    	frame.setVisible(true);
    	JOptionPane.showMessageDialog(frame, string);
    	frame.setVisible(false);
    }
	
    /**
     * Creates the login button
     */
    public void createLoginButton()
    {
    	//Set login button
		loginB.setBackground(new Color(175, 238, 238));
		loginB.setBounds(60, 320, 115, 40);
		loginB.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				try {
			    	File file;
			    	file = new File(getUsernameField() + ".xml");
			    	
					if(file.exists())
					{
				    	reader.readXML(getUsernameField() + ".xml");
				    	fileData.addAll(reader.getRolev());
				    	if ((fileData.get(0).equals(getUsernameField())) && (fileData.get(1).equals(getPasswordField())))
				    			{
				    				showDialog("Log in Successful");
				    				//Start dashboard if login works
				    				TaskerDashboard dash = new TaskerDashboard(fileData.get(0));
				    			}
				    	else 
				    	{
				    		showDialog("Log in Failed");
				    	}		    		
				    }
					else
					{
						showDialog("Wrong Username/Password.");
					}
				} 
				catch (Exception e) {
					e.printStackTrace();
				}
			}
		
		});
		contentPane.add(loginB);	
    }
    
    /**
     * Creates create user button
     */
    public void createCreateUserButton()
    {
		createB.setBackground(new Color(175, 238, 238));
		createB.setBounds(185, 312, 115, 25);
		createB.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				try {
					Path path = Paths.get(getUsernameField() + ".xml");
					
					if(!Files.exists(path)){
						if(getPasswordField().length() >= 6 && getUsernameField().length() >= 3)
						{
							writer.setPassword(getPasswordField());
					    	writer.setUsername(getUsernameField());
							writer.saveToXML(getUsernameField() + ".xml");
							showDialog("Account created.");
						}
						else
							showDialog("Username/Password is not long enough.");
					}
					else
						showDialog("Account exists already.");
				} 
				catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		contentPane.add(createB);
    }
    
    /**
     * Creates the delete user button
     */
    public void createDeleteUserButton()
    {
		deleteB.setBackground(new Color(175, 238, 238));
		deleteB.setBounds(185, 345, 115, 25);
		deleteB.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				try {
					Path path = Paths.get(getUsernameField() + ".xml");
					
					if(Files.deleteIfExists(path))
					{
						showDialog("Your account has been deleted!");
					}
					else
					{
						showDialog("Failed to delete account.");
					}
				} 
				catch (Exception e) {
					showDialog("You just created this account. Close the app and try again.");
				}
			}
		});
		contentPane.add(deleteB);   	
    }
    
    /**
     * Creates the company website button
     */
    public void createCompanyWebsiteButton()
    {
		companyB.setBackground(new Color(175, 238, 238));
		companyB.setBounds(12, 440, 137, 25);
		companyB.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				try {
					URL url;
					url = new URL("http://grove.cs.jmu.edu/groverf/");
					openWebpage(url);
				} 
				catch (MalformedURLException e) {
					e.printStackTrace();
				}
			}
		});
		contentPane.add(companyB);
    }
    
    /**
     * initializes the app
     */
	public void init()
	{	
		//Create contentPane
		contentPane = (JPanel)rootPaneContainer.getContentPane();
		contentPane.setLayout(null);
		contentPane.setBackground(new Color(23, 200, 205));
		
		//Set username label
		username.setBounds(150, 130, 67, 16);
		contentPane.add(username);
		
		//Set password label
		password.setBounds(150, 214, 64, 16);
		contentPane.add(password);
		
		//Set user field
		userField.setBackground(new Color(220, 220, 220));
		userField.setBounds(97, 159, 171, 22);
		contentPane.add(userField);
		
		//Set password field
		passField.setBackground(new Color(220, 220, 220));
		passField.setBounds(97, 243, 171, 22);
		contentPane.add(passField);
		
		//Set BAMFTasker title
		title.setForeground(new Color(0, 0, 0));
		title.setBackground(new Color(255, 255, 255));
		title.setFont(new Font("Simplified Arabic", Font.BOLD, 24));
		title.setBounds(115, 66, 137, 31);
		contentPane.add(title);
		
		//Add buttons
		createLoginButton();
		createCreateUserButton();
		createDeleteUserButton();
		createCompanyWebsiteButton();
		
		contentPane.setVisible(true);
	}
	
	/**
	 * Gets the text within the username text field 
	 * @return the string in the username text field
	 */
	public String getUsernameField()
	{
		return userField.getText(); 
	}
	
	/**
	 * Gets the text within the password text field 
	 * @return the string in the password text field
	 */
	public String getPasswordField()
	{
		return passField.getText();
	}
	
	/**
	 * Used to open the company web  page 
	 * @param uri
	 */
	public static void openWebpage(URI uri) {
	    Desktop desktop = Desktop.isDesktopSupported() ? Desktop.getDesktop() : null;
	    if (desktop != null && desktop.isSupported(Desktop.Action.BROWSE)) {
	        try {
	            desktop.browse(uri);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	}
	
	/**
	 * Used to open the company web page 
	 * @param url 
	 */
	public static void openWebpage(URL url) {
	    try {
	        openWebpage(url.toURI());
	    } catch (URISyntaxException e) {
	        e.printStackTrace();
	    }
	}
	
	 /**
     * Called to indicate that this MultimediaApp should start
     * (required by MultimediaApp)
     */
    public void start()
    {
       new TaskerApp();
    }

    /**
     * Called to indicate that this MultimediaApp should stop
     * (required by MultimediaApp)
     */
    public void stop()
    {
       new TaskerApp();
    }
}
