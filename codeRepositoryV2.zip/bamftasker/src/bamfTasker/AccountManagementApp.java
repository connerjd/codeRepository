package bamfTasker;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.io.File;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;

import io.*;

/**
 * A JPanel that serves as the account management portion of the TaskerApp
 * 
 * @version @version 1.0 , October 20, 2013
 * @author Group 2-2, James Madison University
 */
public class AccountManagementApp extends JPanel{
	
	private JTextField textFieldUser;
	private JTextField textFieldPass;
	private Writer writer = new Writer();
	private Reader reader = new Reader();
	private ArrayList<String> fileData = new ArrayList<String>(2);
	private String name;
	private File file = new File("temp.txt");
	
	/**
	 * Constructor
	 * 
	 * @param name name of the user
	 */
	public AccountManagementApp(String name) {

		this.setBackground(new Color(250, 250, 210));
		this.setForeground(new Color(152, 251, 152));
		this.setLayout(null);
		
		textFieldUser = new JTextField();
		textFieldUser.setBounds(138, 46, 116, 22);
		this.add(textFieldUser);
		textFieldUser.setColumns(10);
		
		JLabel lblUsername = new JLabel("Username :");
		lblUsername.setBounds(40, 49, 86, 16);
		this.add(lblUsername);
		
		JButton changeNameB = new JButton("Change Username/Password");
		changeNameB.setBounds(292, 74, 197, 25);
		
		changeNameB.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					writer.setPassword(getPassword());
			    	writer.setUsername(getUsername());
					writer.saveToXML(getUsername() + ".xml");
					showDialog("Your account has been changed!");
				} 
				catch (Exception e) {
					showDialog("Your account was not changed.");
				}
			}
		});
		this.add(changeNameB);
		
		JLabel lblPassword = new JLabel("Password :");
		lblPassword.setBounds(40, 108, 73, 16);
		this.add(lblPassword);
		
		textFieldPass = new JTextField();
		textFieldPass.setBounds(138, 105, 116, 22);
		this.add(textFieldPass);
		textFieldPass.setColumns(10);
		
        Path path = Paths.get(name + ".xml");
    	
		if(Files.exists(path))
		{
	    	reader.readXML(name + ".xml");
	    	fileData.addAll(reader.getRolev());
	    	textFieldUser.setText(fileData.get(0));
			textFieldPass.setText(fileData.get(1));
	    }
		else
		{
			showDialog("Can not find the account." + name);
		}
		
	}
	
	/**
     * Shows a dialog in a dialog box
     * @param string what is said in the box
     */
	public void showDialog(String string)
    {
    	JFrame frame = new JFrame();
    	frame.setBounds(500, 500, 150, 50);
    	frame.setVisible(true);
    	JOptionPane.showMessageDialog(frame, string);
    	frame.setVisible(false);
    }
	
	
	/**
	 * Returns the string within the textFieldUser field
	 * @return String the string in the textFieldUser field
	 */
	public String getUsername()
	{
		return textFieldUser.getText(); 
	}
	
	/**
	 * Returns the string within the textFieldPass field
	 * @return String the string in the textFieldPass field
	 */
	public String getPassword()
	{
		return textFieldPass.getText();
	}
}
