package io;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;
import org.xml.sax.*;
import org.w3c.dom.*;

public class Reader
{
    private String username = null;
    private String password = null;

	private ArrayList<String> rolev;

    public boolean readXML(String xml)
    {
        rolev = new ArrayList<String>();
        Document dom;
        // Make an instance of the DocumentBuilderFactory
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        try
        {
            // use the factory to take an instance of the document builder
            DocumentBuilder db = dbf.newDocumentBuilder();
            // parse using the builder to get the DOM mapping of the
            // XML file
            dom = db.parse(xml);

            Element doc = dom.getDocumentElement();

            username = getTextValue(username, doc, "username");
            {
                if (!username.isEmpty())
                    rolev.add(username);
            }
            password = getTextValue(password, doc, "password");
            if (password != null)
            {
                if (!password.isEmpty())
                    rolev.add(password);
            }
            return true;

        }
        catch (ParserConfigurationException pce)
        {
            System.out.println(pce.getMessage());
        }
        catch (SAXException se)
        {
            System.out.println(se.getMessage());
        }
        catch (IOException ioe)
        {
            System.err.println(ioe.getMessage());
        }

        return false;
    }
    private String getTextValue(String def, Element doc, String tag) {
        String value = def;
        NodeList nl;
        nl = doc.getElementsByTagName(tag);
        if (nl.getLength() > 0 && nl.item(0).hasChildNodes()) {
            value = nl.item(0).getFirstChild().getNodeValue();
        }
        return value;
    }
    public ArrayList<String> getRolev() {
		return rolev;
	}
	public void setRolev(ArrayList<String> rolev) {
		this.rolev = rolev;
	}

}
